import React from "react"
//import Rainbow from "../HigherOrderComp/rainbow"

const About = () => {
    // setTimeout(() => {
    //     props.history.push("/About")
    // }, 2000);
    return (
        <div className="container">
            <h4 className="center">About</h4>
            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Commodi accusamus natus alias adipisci sit maiores exercitationem corporis rem perspiciatis, eligendi aut? Facilis, modi similique laudantium ad itaque assumenda consectetur molestiae.</p>
        </div>
    )
}
export default (About)